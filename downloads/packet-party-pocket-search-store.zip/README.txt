PACKET PARTY - POCKET SEARCH 1.3.1

Desktop Chrome, Microsoft Edge and Brave (Manifest V3).

PUBLIC DOWNLOAD + BROWSER-SPECIFIC GUIDE
https://packet-party-angelowww11s-projects.vercel.app/get-extension

NO-INSTALL ONLINE VERSION
https://packet-party-angelowww11s-projects.vercel.app/pocket

INSTALL
1. Extract the ZIP. Keep the extracted folder in a permanent location.
2. Open your browser's Extensions page:
   Chrome: chrome://extensions
   Edge:   edge://extensions
   Brave:  brave://extensions
3. Turn Developer mode ON.
4. Choose Load unpacked and select the packet-party-pocket-search folder
   containing manifest.json. Do not select the ZIP or its parent folder.
5. Pin Packet Party using the puzzle-piece Extensions menu.

USE
Press the backtick key (`) on a normal webpage to show/hide the compact
360 x 440 question box. Type or paste your question into its own input.
The answer appears directly below; choices and explanations can be expanded.
The shortcut also hides the box while its question input is focused.
Backtick shows/hides the box from webpage text fields and embedded frames too.
Refresh already-open webpages after installing/updating to activate the shortcut.
The toolbar icon and Ctrl+Shift+Y (Command+Shift+Y on Mac) also show/hide it.
Showing/hiding keeps the extension running and preserves the question/results.
Each tab keeps its own question draft for the current browser session.
Returning to a tab repairs missing listeners, removed panels and unloaded frames.
The shortcut shows/hides after the key is released, before focus moves.
Copy selected webpage text to replace the question and search automatically.
This also updates the question while hidden/minimized, without opening the box
or moving keyboard focus. Show the box to see the latest copied question.
Uncheck Search copied text in the box to pause automatic import. This observes
webpage copy actions only; it does not monitor your system clipboard.
Drag the bottom-right corner to resize, or enter W/H values in the bottom bar.
Your chosen size is saved; Reset restores 360 x 440.
Results update as you type; Enter searches immediately.
Use the bank filter to choose Original pools, CCST, Summative 3, or all three.
Correct choices glow by default. Show/hide answers and expand explanations.
Grouped True/False questions and drag/drop matches show each answer separately.
Exhibits are bundled. Search never invents an answer for missing questions.

Drag the header to move the panel; minimize it to a small floating square.
Drag the square to move it. Click it to reopen. Escape minimizes the panel.
The close button hides it. Press backtick to reopen, even after navigation.

Restricted browser pages and some viewers do not allow floating panels;
the toolbar icon opens a small separate search window there instead.
Browser settings pages cannot receive the single backtick page shortcut.

509 QUESTIONS / THREE BANKS
Original pools: 198. CCST certification: 99. Summative 3: 212.
The bank is a bundled snapshot, including source disagreements and corrections
already displayed on Packet Party. Different saved source keys are kept as
separate results. Explanation notes describe conflicts where known.
Download a newer ZIP and reload/reinstall to get later bank updates.

PRIVACY / PERMISSIONS
activeTab + scripting: show the floating panel on the tab you explicitly open it on.
HTTP/HTTPS content-script and host access: listen for backtick in pages/frames
and repair the listener when switching tabs, loading a page or updating.
The panel may load invisibly after a copy, but only shows when you show it.
Selected text is imported when Search copied text is enabled, including while
hidden/minimized. Other page text is not scanned.
storage: remember your last pasted query, bank and answer/explanation settings.
No background clipboard monitoring, tracking, remote AI or account login.
When Search copied text is enabled, a webpage copy action reads only the copied
selection and searches it locally. Page text is not scanned automatically.
Searches run locally against the bundled bank and work without internet.
Clear search to remove the saved query; uninstall to remove all extension storage.
Open Packet Party follows a normal external link only when you click it.

This is a downloadable unpacked extension, not a Chrome Web Store or Edge
Add-ons listing. Desktop browser extensions are separate from the mobile PWA.

SOURCE / UPDATES
https://github.com/Angelowww11/REVIEWERS_HAVEFUN
https://packet-party-angelowww11s-projects.vercel.app/extension.html

PRIVACY
https://packet-party-angelowww11s-projects.vercel.app/extension-privacy.html
